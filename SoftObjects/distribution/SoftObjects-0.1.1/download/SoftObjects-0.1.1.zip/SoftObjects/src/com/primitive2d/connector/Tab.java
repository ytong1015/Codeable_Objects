package com.primitive2d.connector;

public class Tab {
//TODO: create tab
}
