package com.primitive2d;

public class Curve {
 //TODO: create curve class
}
